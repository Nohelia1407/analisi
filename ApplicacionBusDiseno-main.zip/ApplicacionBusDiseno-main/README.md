# ApplicacionBusDiseno
 App de bus y monedero virtual, diseño de sistemas.
