import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogInChoferComponent } from './log-in-chofer.component';

describe('LogInChoferComponent', () => {
  let component: LogInChoferComponent;
  let fixture: ComponentFixture<LogInChoferComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LogInChoferComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogInChoferComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
