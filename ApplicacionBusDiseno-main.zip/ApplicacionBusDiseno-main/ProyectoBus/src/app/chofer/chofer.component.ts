import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chofer',
  templateUrl: './chofer.component.html',
  styleUrls: ['./chofer.component.css']
})
export class ChoferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
