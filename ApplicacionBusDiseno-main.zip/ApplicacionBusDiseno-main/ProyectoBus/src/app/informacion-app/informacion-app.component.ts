import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-informacion-app',
  templateUrl: './informacion-app.component.html',
  styleUrls: ['./informacion-app.component.css']
})
export class InformacionAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
