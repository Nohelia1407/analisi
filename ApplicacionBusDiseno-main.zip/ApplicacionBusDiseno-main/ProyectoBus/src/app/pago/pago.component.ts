import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-pago',
  templateUrl: './pago.component.html',
  styleUrls: ['./pago.component.css']
})
export class PagoComponent implements OnInit {
  FormPago = this.formBuilder.group({
    Monto_Pago: '',
    Id_Chofer: '',
    Id_usuario: localStorage.getItem('Id_usuario')
  });
  Choferes: any[] = [];

  constructor(
    private formBuilder: FormBuilder,
    private http: HttpClient
  ) {
    this.SelecChofer();
  }

  ngOnInit(): void {
  }
  SelecChofer() {
    this.http.get<any>("http://localhost:8080/Usuario_Chofer").subscribe(data => {
      this.Choferes = data
      console.log(data)
    })


  }
  Pagar() {
    console.log(this.FormPago.value)
    this.http.post("http://localhost:8080/Pago_Chofer", this.FormPago.value).subscribe()
    this.FormPago.reset();
  }
}
