import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogInAdmiComponent } from './log-in-admi.component';

describe('LogInAdmiComponent', () => {
  let component: LogInAdmiComponent;
  let fixture: ComponentFixture<LogInAdmiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LogInAdmiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogInAdmiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
