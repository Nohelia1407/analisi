import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogInClienteComponent } from './log-in-cliente.component';

describe('LogInClienteComponent', () => {
  let component: LogInClienteComponent;
  let fixture: ComponentFixture<LogInClienteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LogInClienteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogInClienteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
