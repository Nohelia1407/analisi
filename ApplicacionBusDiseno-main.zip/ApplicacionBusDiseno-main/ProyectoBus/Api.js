const express = require('express');
const sql = require('mssql/msnodesqlv8'); // Librería para conectar con SQL server
const bodyParser = require('body-parser');


const app = express();// variable para usar el API
app.use(bodyParser.json())
const port = process.env.PORT || 8080;// puerto que utiliza el API

app.use(function (req, res, next) {

  // Website you wish to allow to connect
  res.setHeader('Access-Control-Allow-Origin', '*');

  // Request methods you wish to allow
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

  // Request headers you wish to allow
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  res.setHeader('Access-Control-Allow-Credentials', true);

  // Pass to next layer of middleware
  next();
});

//Configuracion de la Base Datos
const config = { 

  server: process.env.DB_SERVER || 'localhost',
  database: process.env.DB_DATABASE || 'Bus',
  trustServerCertificate : true, 
  options: {
    trustedConnection: true //Windows Authentication
  },
}

app.get('/Admin', function(req, res){
  var adminQuery = `select * from Admin`  //Query que se va a ejecutar
  const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
  request.query(adminQuery, (err, result) => { //Hace la consulta
    if (err) res.status(500).send(err);
    res.send(result['recordsets'][0]);  // Si es correcto lo guarda en la variable result
 });

})

app.get('/Tarjeta_Banco/:Id_usuario', function(req, res){
  var tarjetasQuery = `SELECT ..Tarjeta_Banco.Numero_Tarjeta, ID_Cuenta FROM Tarjeta_Banco
  WHERE Id_usuario = `+req.params.Id_usuario  //Query que se va a ejecutar
  const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
  request.query(tarjetasQuery, (err, result) => { //Hace la consulta
    if (err) res.status(500).send(err);
    res.send(result['recordsets'][0]);  // Si es correcto lo guarda en la variable result
 });

})


app.get('/Usuario_Chofer', function(req, res){
  var tarjetasQuery = `SELECT TOP (1000) CONCAT([Nombre],' ',[Apellido])AS Chofer
  ,[Id_usuario] AS Id_Chofer
FROM [Bus].[dbo].[Usuario] where Id_tipo_usuario=3 `//Query que se va a ejecutar
  const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
  request.query(tarjetasQuery, (err, result) => { //Hace la consulta
    if (err) res.status(500).send(err);
    res.send(result['recordsets'][0]);  // Si es correcto lo guarda en la variable result
 });

})

app.get('/Ubicacion', function(req, res){
  var tutoriasQuery = `SELECT [Tarifa_Parada]
  ,[Localizacion]
  FROM [Parada]`  //Query que se va a ejecutar
  const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
  request.query(tutoriasQuery, (err, result) => { //Hace la consulta
    if (err) res.status(500).send(err);
    res.send(result['recordsets'][0]);  // Si es correcto lo guarda en la variable result
 });

})

 app.get('/Usuario_Pasajero', function(req, res){
  var eliminacQuery = `SELECT [Nombre]
  ,[Apellido]
  ,[Id_usuario]
  ,[Correo]
  ,[Saldo]
FROM [Usuario]
WHERE Id_tipo_usuario = 2`  //Query que se va a ejecutar
  const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
  request.query(eliminacQuery, (err, result) => { //Hace la consulta
    if (err) res.status(500).send(err);
    res.send(result['recordsets'][0]);  // Si es correcto lo guarda en la variable result
 });

})

app.get('/Elimina_Clientes:Id_usuario', function(req, res){
  var consultaQuery = `DELETE FROM [Usuario]
  WHERE Id_usuario = ` +req.params.Id_usuario  //Query que se va a ejecutar
  const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
  request.query(consultaQuery, (err, result) => { //Hace la consulta
    if (err) res.status(500).send(err);
 });

})

app.post('/Parada', function(req, res){ 
  //Formando Query
   var usuarioQuery = `INSERT INTO Parada VALUES (`+ 
   req.body.Tarifa_Parada +`,'` + 
   req.body.Localizacion + `',`+  
   req.body.Id_Chofer +  
   `);` //Query que se va a ejecutar
 console.log(usuarioQuery) //El parametro que le envio se guarda en req.body
 //Ejecutar Query
 const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
   request.query(usuarioQuery, (err, result) => { //Hace la consulta
     if (err) res.status(500).send(err);
  }); 
 })

app.post('/Pago_Chofer', function(req, res){ 
  //Formando Query
   var recargaQuery = `INSERT INTO Pago VALUES (`+ 
   req.body.Monto_Pago + `,`+ 
   req.body.Id_usuario +  
   `);
UPDATE Usuario SET Saldo -= `+ req.body.Monto_Pago + `
WHERE Id_usuario = `+req.body.Id_usuario +
`;
UPDATE Usuario SET Saldo += `+ req.body.Monto_Pago + `
WHERE Id_usuario = `+req.body.Id_Chofer//Query que se va a ejecutar
 console.log(recargaQuery) //El parametro que le envio se guarda en req.body
 //Ejecutar Query
 const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
   request.query(recargaQuery, (err, result) => { //Hace la consulta
     if (err) res.status(500).send(err);
  }); 
 })

app.post('/Recarga_Tarjeta', function(req, res){ 
  //Formando Query
   var recargaQuery = `INSERT INTO Recargas VALUES (`+ 
   req.body.ID_Cuenta +`,` + 
   req.body.Monto_Recarga + `,`+ 
   req.body.Id_usuario +  
   `);
UPDATE Usuario SET Saldo += `+ req.body.Monto_Recarga + `
WHERE Id_usuario = `+req.body.Id_usuario //Query que se va a ejecutar
 console.log(recargaQuery) //El parametro que le envio se guarda en req.body
 //Ejecutar Query
 const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
   request.query(recargaQuery, (err, result) => { //Hace la consulta
     if (err) res.status(500).send(err);
  }); 
 })
// Crea Usuarios normales = Pasajeros
app.post('/Usuario', function(req, res){ 
 //Formando Query
  var usuarioQuery = `INSERT INTO Usuario VALUES ('`+ 
  req.body.Nombre +`','` + 
  req.body.Apellido + `','`+ 
  req.body.Contrasenna + `','`+ 
  req.body.Correo + `',`+ 
  `0` + `,`+ 
  `2` + `);` //Query que se va a ejecutar
console.log(usuarioQuery) //El parametro que le envio se guarda en req.body
//Ejecutar Query
const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
  request.query(usuarioQuery, (err, result) => { //Hace la consulta
    if (err) res.status(500).send(err);
 }); 
})

// Crea Usuarios normales = Choferes
app.post('/UsuarioChofer', function(req, res){ 
  //Formando Query
   var usuarioQuery = `INSERT INTO Usuario VALUES ('`+ 
   req.body.Nombre +`','` + 
   req.body.Apellido + `','`+ 
   req.body.Contrasenna + `','`+ 
   req.body.Correo + `',`+ 
   `0` + `,`+ 
   `3` + `);` //Query que se va a ejecutar
 console.log(usuarioQuery) //El parametro que le envio se guarda en req.body
 //Ejecutar Query
 const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
   request.query(usuarioQuery, (err, result) => { //Hace la consulta
     if (err) res.status(500).send(err);
  }); 
 })

 // Crea Administradores
 app.post('/Admin', function(req, res){ 
  //Formando Query
   var adminQuery = `INSERT INTO Admin VALUES ('`+ 
   req.body.Correo + `','`+ 
   req.body.Contrasenna + `','`+ 
   `1` + `);` //Query que se va a ejecutar
 console.log(adminQuery) //El parametro que le envio se guarda en req.body
 //Ejecutar Query
 const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
   request.query(adminQuery, (err, result) => { //Hace la consulta
     if (err) res.status(500).send(err);
  }); 
 })

// Crea Monederos
app.post('/Tarjeta_Banco', function(req, res){ 
  //Formando Query
   var tarjetaQuery = `INSERT INTO Tarjeta_Banco VALUES (`+ 
   req.body.Numero_Tarjeta + `,`+ 
   req.body.Mes + `,`+  
   req.body.Ano + `,`+ 
   req.body.Codigo + `,`+
   req.body.Id_usuario + `);` //Query que se va a ejecutar
 console.log(tarjetaQuery) //El parametro que le envio se guarda en req.body
 //Ejecutar Query
 const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
   request.query(tarjetaQuery, (err, result) => { //Hace la consulta
     if (err) res.status(500).send(err);
  }); 
 })

//Iniciar sesion
app.post('/LoginCliente', function(req, res){ 
  //Formando Query
   var usuarioQuery = "SELECT * FROM  Usuario WHERE Correo='"
   + req.body.Correo + "' AND Contraseña= '" + req.body.Contrasenna + "'"+ " AND Id_tipo_usuario = " + req.body.TipoUsuario ; 
                                                                          
                                                                          
   //Query que se va a ejecutar
 console.log(usuarioQuery) //El parametro que le envio se guarda en req.body
 //Ejecutar Query
  const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
   request.query(usuarioQuery, (err, result) => { //Hace la consulta
     if (err) res.status(500).send(err);
     console.log(result['recordsets'][0])
     res.send(result['recordsets'][0]);
  }); 
 })

 app.post('/LoginAdmin', function(req, res){ 
  //Formando Query
   var usuarioQuery = "SELECT * FROM  Admin WHERE Correo='"
   + req.body.Correo + "' AND Contraseña= '" + req.body.Contrasenna + "'"; //Query que se va a ejecutar
 console.log(usuarioQuery) //El parametro que le envio se guarda en req.body
 //Ejecutar Query
  const request = new sql.Request();  //Variable tipo request que me permite hace una consulta.
   request.query(usuarioQuery, (err, result) => { //Hace la consulta
     if (err) res.status(500).send(err);
     console.log(result['recordsets'][0])
     res.send(result['recordsets'][0]);
  }); 
 })

 


// Para que instalen todo solo ponen el comando npm install

// configure app to use bodyParser()
// this will let us get the data from a POST





// START THE SERVER
// =============================================================================
sql.connect(config, err => {
  if (err) {
     console.log('Failed to open a SQL Database connection.', err.stack);
     process.exit(1);
  }
  app.listen(port, () => {
     console.log(`App is listening at http://localhost:${port}`);
  });
});



